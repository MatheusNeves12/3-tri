criaCartao(
    'História',
    'Em que período o fogo foi desccoberto?',
    'No período paleolítico.'
)

criaCartao(
    'Matemática',
    'Quantas casas decimais tem o número Pi?',
    'Ele possui infinitas casas!'
)

criaCartao(
    'Geografia',
    'Quais os países com maior e menor expectativa de vida?',
    'Japão (84 anos) e Serra Leoa (53 anos).'
)

criaCartao(
    'Química',
    'Atualmente,  quantos elementos químicos a tabela periódica possui??',
    'Possui 118 elementos.'
)

criaCartao(
    'Conhecimentos Gerais',
    'Qual o número mínimo de jogadores em cada time numa partida de futebol?',
    '7 jogadores'
)

criaCartao(
    'Ciências',
    'Quanto tempo que a luz do Sol demora para chegar a Terra?',
    'Demora 8 minutos'
)

criaCartao(
    'Física',
    'Qual a velocidade da luz?',
    '299.792.458 m/s.'
)

criaCartao(
    'Folclóre Brasileiro',
    'Qual personagem é agradado pelos caçadores com oferta de fumo?',
    'Personagem Caipora.'
)

criaCartao(
    'História',
    'Qual é o nome do presidente do Brasil que ficou conhecido como Jango?',
    'Presidente João Goulart.'
)
